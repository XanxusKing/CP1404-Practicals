

print('hello world')